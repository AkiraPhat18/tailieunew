<?php

session_start();

 ?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Quản lý</title>
</head>

<style type="text/css">
	* {
		margin: 0;
		padding: 0;
	}
	
	body {
		margin: 0 auto;
		padding: 0;
		width: 1200px;
		background: #2D2D2D;
		
	}
	
	#container {
		position: relative;	
	}
	
	#header {
		height: 323px;
	}
	
	#menu ul {
		background: #47bdec;
		list-style-type: none;
		text-align: center;
	}
	
	#menu ul li {
		display: inline-table;
		width: 150px;
		height: 40px;
		line-height: 40px;
		position: relative;
		
	}
	
	#menu ul li a {
		text-decoration: none;
		display: block;
		color: #f1f1f1;
		transition: all 1s;
		-moz-transition: all 1s;
		-webkit-transition: all 1s;
	}
	
	#menu ul li a:hover {
		background: #333;
		color: #F3C;
		font-weight: bold;
	}
	
	#sub-menu {
		display: none;
		position: absolute;
	}
	
	#menu ul li:hover #sub-menu {
		display: block;
	}
	
	#footer {
		background: #47bdec;
		clear: both;
		height: 60px;
		line-height: 60px;
		text-align: center;
	}
	
	#content {
		height: auto;;
	}
	
	#content-left {
		width: 30%;
		float: left;
		height: 800px;
		background: #93F;
	}
	
	#content-left ul {
		list-style-type: none;
		text-align: center;
		background: #363636;
	}
	
	#content-left ul li {
		height: 40px;
		line-height: 40px;
		border-bottom: 1px solid #FFF;
		transition: all 1s;
		-moz-transition: all 1s;
		-webkit-transition: all 1s;
	}
	
	#content-left ul li a {
		text-decoration: none;
		display: block;
		color: white;
		
	}
	
	#content-left ul li:hover {
		background: #7F1F55;
		color: #906;
		font-weight: bold;
	}
	
	#sub-menu1 {
		position: absolute;
		left: 362px;
		top: 445px;
		color: #03F;
		display: none;
	}
	
	#content-left ul li:hover #sub-menu1 {
		display: block;
	}
	
	#content-right {
		width: 69.9%;
		float: right;
		text-align: justify;
		border-left: 1px solid #CCC;
		height: 800px;
		background: #FFC;
	}
	
	table {
		width: 500px;
		background: #FFF;
		margin-left: auto;
		margin-right: auto;
		text-align: center;
	}
	
	
	
</style>

<body>
	<div id="container">
        <div id="header"><img src="23760060_856467994533559_2101777534_o.png" width="1200px"></div>
        
        <div id="menu">
            <ul>
                <li><a href="#">Trang chủ</a></li>
                <li><a href="#">Tin tức</a></li>
                <li>
                    <a href="#">Giới thiệu</a>
                    <ul id="sub-menu">
                        <li><a href="#">Giới thiệu 1</a></li>
                        <li><a href="#">Giới thiệu 2</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#">Sản phẩm</a>
                    <ul id="sub-menu">
                        <li><a href="#">Sản phẩm 1</a></li>
                        <li><a href="#">Sản phẩm 2</a></li>
                        <li><a href="#">Sản phẩm 3</a></li>
                        <li><a href="#">Sản phẩm 4</a></li>
                    </ul>
                </li>
                <li><a href="#">Liên hệ</a></li>
                <li><a href="#">Đặt hàng</a></li>
            </ul>
        </div>
        
        <div id="content">
        	<div id="content-left">
            
            
            	<ul>
                	<li><a href="test.php?ac=tracuu&th=1">Tra cứu nhân viên</a></li>
                	<li><a href="test.php?ac=phancong&th=1">Phân công ca làm</a></li>
                    <li><a href="#">Quản lý nhân viên</a>
                    	<ul id="sub-menu1">
                        	<li><a href="test.php?ac=themnv&th=1">Thêm nhân viên</a></li>
                            <li><a href="test.php?ac=suanv&th=1">Sửa nhân viên</a></li>
                        </ul>
                    </li>
                	<li><a href="test.php?ac=luong&th=1">Quản lý lương</a></li>
                </ul>
                
                
            <center><br/>
            <div style="height:200px; width:250px; background:#06F; color:#FFF; border:double; font-size:20px;">
            <?php
include('connect.php');
$name = $_SESSION['username'];
$chuc ="";

while($kq = mysql_fetch_array($run)){
	
	if($name ==$kq['username']){
	
	echo "<br/>Xin chào, ".$kq['hoten'];	
		
	if($kq['chuc']==0){
		echo "<br/><br/>Chức vụ: Nhân viên";
		$chuc = $kq['chuc'];
		}
		else echo "<br/><br/>Chức vụ: Quản lý";
	$chuc = $kq['chuc'];
	}
}


 ?>
 <br/><br /> <br/>
<a href="http://localhost:8888/WebstieQuanLiTiemBanh/" > <input type="button" style="height:30px; width:80px; background: #903; color:#FFF" value="Đăng xuất" /> </a>
            
            </div>
            </center>
                
            </div>
            
            
            <div id="content-right">
            	<h2 style="text-align: center; background: #FCF; color:#F00">QUẢN LÝ</h2>
            	<div id="content-1">
                	<!-- them muc vao day -->
                    
                    <?php 
					$tam = $_GET['ac'];
					
					if ($tam == 'tracuu'){
						include('tracuu.php');
					}
					elseif($tam =='themnv') {
						if($chuc==1){
					include ('themnv.php');
					
						}
						else{
							include('loitruycap.php');
							
							}
					}
					elseif($tam =='suanv') {
						if($chuc==1){
					include ('suanv.php');
					
						}
						else{
							include('loitruycap.php');
							
							}
					}
					elseif($tam =='luong') {
					include ('quanliluong.php');
					}
					elseif($tam =='phancong') {
						if($chuc==1){
					include ('phancong.php');
					
						}
						else{
							include('loitruycap.php');
							
							}
					}
					?>
                </div>     
            </div>
        </div>
        
        <div id="footer">
        	Copyright &copy;2017 by Fang to beens - KTPM5 - K10 - HaUI.
        </div>
	</div>
</body>
</html>