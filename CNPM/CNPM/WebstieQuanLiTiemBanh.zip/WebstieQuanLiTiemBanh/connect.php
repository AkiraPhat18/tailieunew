
<?php
// echo "Hello wold"; 

$host = 'localhost';
$csdl = 'tiembanhtestdb';
$ten = 'root';
$pass = '';

$conn = mysql_connect($host,$ten,$pass);
//mysql_connect("localhost","root","");

mysql_select_db("tiembanhtestdb");

$run = mysql_query("select * from taikhoan");



 ?>