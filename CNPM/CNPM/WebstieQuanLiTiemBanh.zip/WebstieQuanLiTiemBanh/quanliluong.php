<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<br/>
<center><h1>Quản lý lương nhân viên</h1></center>
<br/><br/>
<?php 
					include('connect.php');
					$sql = "select * from nhanvien order by manv asc";
					$run2 = mysql_query($sql);
					?>
                    
                	<table border="1" cellspacing="0">
                    	<tr>
                        	<td>Mã NV</td>
                            <td>Tên NV</td>
                            <td>Ngày công</td>
                            <td>Ngày muộn</td>
                            <td>Lương</td>
                            
                        </tr>
                        
                        <?php
							
							$i =0;
							
							while ($kq=mysql_fetch_array($run2)){
						
						 ?>
                        
                        <tr >
                        	<td style="width:200px; height:60px"><?php echo $kq['manv'] ?></td>
                            <td style="width:200px; height:60px"><?php echo $kq['tennv'] ?></td>
                            <td style="width:200px; height:60px"><?php echo $kq['ngaycong'] ?></td>
                            <td style="width:200px; height:60px"><?php echo $kq['buoimuon'] ?></td>
                            <td style="width:200px; height:60px"><?php echo ($kq['ngaycong']-$kq['buoimuon'])*100000 + ($kq['buoimuon']*80000) ?></td>
                           
                        </tr>
                        
                        <?php
                        
							$i++;
						
							}
						?>
                        
                    </table>



</body>
</html>