<?php
	include('connect.php');
	include('checkuser.php');
	$sql2 = mysql_query("select id,manv,username from taikhoan,nhanvien order by id asc");
	$manv = $_POST['manv'];
	$gt = $_POST['gt'];
	$ngaysinh = $_POST['ngaysinh'];
	$sdt = $_POST['sdt'];
	$username = $_POST['taikhoan'];
	$password = $_POST['matkhau'];
	$hoten = $_POST['tennv'];
	$ok = 1;
	$id = 0;
	$luong =0;
	$muon =0;
	if (isset($_POST['thembtn'])){
		
		while ($kq2 = mysql_fetch_array($sql2)){
			
				if($manv==$kq2['manv']||$username==$kq2['username']||$ngaysinh==""||$sdt==""||$password==""){
					$ok=0;
					header('location:test.php?ac=themnv&th=0');
					
					break;
					}
				$id = $kq2['id']+1;
			
			}
			if ($ok ==1){
				$sqlThem = "insert into taikhoan values ('$id','$hoten','$username','$password') ";
				$sqlthem2 = "insert into nhanvien values ('$id','$hoten','$gt','$ngaysinh','$sdt','$luong','$muon');";
				mysql_query($sqlThem);
				mysql_query($sqlthem2);
				header('location:test.php?ac=themnv&th=2');
				
			}
		
	}
	
	
	


 ?>