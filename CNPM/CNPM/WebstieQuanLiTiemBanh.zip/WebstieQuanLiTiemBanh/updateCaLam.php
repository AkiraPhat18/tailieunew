<?php 

include('connect.php');

$id = $_POST['manv'];

$ca = $_POST['calam'];

if (isset($_POST['okbtn'])){
	
	mysql_query("update nhanvien set calam = '$ca' where manv = '$id' ");
	header("location:test.php?ac=phancong&th=1");
	}

?>