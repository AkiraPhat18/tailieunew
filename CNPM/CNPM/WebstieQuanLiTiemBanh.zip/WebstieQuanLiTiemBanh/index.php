<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Fang to beens - Cake store</title>
</head>

<style type="text/css">
	* {
		margin: 0;
		padding: 0;
	}
	
	body {
		margin: 0 auto;
		padding: 0;
		width: 1200px;
		background: #2D2D2D;
		
	}
	
	#container {
		position: relative;
		background: #FFA;
		
	}
	
	#header {
		height: 323px;
	}
	
	#menu ul {
		background: #47bdec;
		list-style-type: none;
		text-align: center;
	}
	
	#menu ul li {
		display: inline-table;
		width: 150px;
		height: 40px;
		line-height: 40px;
		position: relative;
		
	}
	
	#menu ul li a {
		text-decoration: none;
		display: block;
		color: #f1f1f1;
		transition: all 1s;
		-moz-transition: all 1s;
		-webkit-transition: all 1s;
	}
	
	#menu ul li a:hover {
		background: #333;
		color: #F3C;
		font-weight: bold;
	}
	
	#sub-menu {
		display: none;
		position: absolute;
	}
	
	#menu ul li:hover #sub-menu {
		display: block;
	}
		
	#content {
		height: auto;
	}
	
	#content-left {
		width: 30%;
		float: left;
		
	}
	
	#content-right {
		width: 69.9%;
		float: right;
		text-align: justify;
		border-left: 1px solid #CCC;
	}
	
	#content-right img {
		display: block;
		margin-left: auto;
		margin-right: auto;
	}
	
	#content #content-1 {
		margin-left: 10px;
		margin-right: 10px;
		margin-top: 10px;
		margin-bottom: 10px;
	}
	
	#footer {
		background: #47bdec;
		clear: both;
		height: 60px;
		line-height: 60px;
		text-align: center;
	}
	
	form table {
		margin: 0 auto;
	}
</style>

<body>
	<div id="container">
        <div id="header"><img src="23760060_856467994533559_2101777534_o.png" width="1200px"></div>
        
        <div id="menu">
            <ul>
                <li><a href="index.php">Trang chủ</a></li>
                <li><a href="#">Tin tức</a></li>
                <li>
                    <a href="#">Giới thiệu</a>
                    <ul id="sub-menu">
                        <li><a href="#">Giới thiệu 1</a></li>
                        <li><a href="#">Giới thiệu 2</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#">Sản phẩm</a>
                    <ul id="sub-menu">
                        <li><a href="#">Sản phẩm 1</a></li>
                        <li><a href="#">Sản phẩm 2</a></li>
                        <li><a href="#">Sản phẩm 3</a></li>
                        <li><a href="#">Sản phẩm 4</a></li>
                    </ul>
                </li>
                <li><a href="#">Liên hệ</a></li>
                <li><a href="#">Đặt hàng</a></li>
            </ul>
        </div>
        
        <div id="content">
        	<div id="content-left">
            	<h2 style="background:#616161; text-align: center; color:#F0F">ĐĂNG NHẬP</h2>
                
              
                
                <form style="background:#A4A4A4" action="checkuser.php" method="post" enctype="multipart/form-data">
                	<table cellspacing="10"> 
                    	<tr>
                        	<td>Tài khoản: </td>
                            <td><input type="text" name="taikhoan"></td>
                        </tr>
                        <tr>
                        	<td>Mật khẩu: </td>
                            <td><input type="password" name="matkhau"></td>
                        </tr>
                        <tr>
                        	<td><input type="submit" name="login" value="Đăng nhập"></td>
                         <!--   <td><input type="submit" name="quenmatkhau" value="Quên mật khẩu"></td>  -->
                        </tr>
                    </table>
                </form>
                
                  
            </div>
            
            <div id="content-right">
            	<h2 style="text-align: center; background: #FCF; color:#F00">TIN TỨC</h2>
            	<div id="content-1">
                    <h3 style="text-align: center">TÁC DỤNG CỦA VIỆC ĂN BÁNH MÌ VỚI SỨC KHỎE</h3>
                 	<br>
                    <p><b><i>Bánh mì đã có sự công nhận xứng đáng là một siêu anh hùng dinh dưỡng chứ không phải là một kẻ thù vỗ béo. Chúng ta cùng xem tác dụng của việc ăn bánh mì là gì nhé!</i></b></p>
                    <br>
                    <h5>6 TÁC DỤNG KHÔNG NGỜ TỪ BÁNH MÌ</h5>
                    <br>
                    <p>Tiến sĩ dinh dưỡng Aine O’Connor nói: “Mặc dù sức tiêu thụ bánh mì đã giảm trong vài thập kỉ qua tuy nhiên nó vẫn mang lại cho chúng ta rất nhiều lợi ích từ việc làm xương khỏe hơn đến cung cấp các loại vitamin”.
    Trong ấn bản mới nhất của Tạp chí dinh dưỡng Bulletin, tiến sĩ O’Connor của Quỹ dinh dưỡng Anh đã viết “Bánh mì cung cấp hơn 10% lượng protein, chất sắt vào cơ thể chúng ta mỗi ngày, giúp chúng ta đáp ứng một số nhu cầu dinh dưỡng quan trọng” .
    Chúng ta ăn trung bình từ 2-3 lát bánh mì mỗi ngày nhưng sau đây sẽ là những lý do mà bạn muốn tăng thêm “con số” đó.</p>
                    <br>
                    <h5>Giúp làn da đẹp:</h5>
                    <p>Làn da chúng ta rất cần protein – chất cần thiết giữ cho da chúng ta khỏe mạnh. Chất dinh dưỡng này thường có trong bít tết, cá và đồ nướng nhưng có một điều ngạc nhiên là nó cũng có trong bánh mì. Vì vậy mà 4 lát bánh mì mỗi ngày có thể cung cấp 1/4 lượng protein cho phụ nữ và 1/5 cho nam giới.</p>
                    <br>
                    <img src="banh-mi1.jpg">
                    <br>
                    <h5>Giúp xương chắc khỏe:</h5>
                    <p>4 lát bánh mì trắng mỗi ngày cung cấp cho chúng ta 164mg calci (giống như 100g sữa chua) trong khẩu phần 800mg calci mỗi ngày mà chúng ta cần nạp vào cơ thể. Các bạn nữ ở độ tuổi 10 đến 15 thường chỉ ăn khoảng 300mg calci mỗi ngày, đây là vấn đề rất nghiêm trọng đối với sự phát triển của xương và nguy cơ gãy xương là rất cao. Vì vậy mà ăn bánh mì vào mỗi bữa sáng hay bữa trưa giúp tăng đáng kể các chất giúp xương chắc khỏe.</p>
                    <br>
                    <img src="bua-sang-ngon-voi-banh-my-nhan-thit-phu-pho-mai (1).jpg">
                    <br>
                    <h5>Giúp não hoạt động tốt nhất:</h5>
                    <p>Chất sắt giúp chúng ta tràn đầy sinh lực và giúp não bộ làm việc chính xác và tự tin. Hiện nay rất nhiều phụ nữ ở Anh ăn quá ít chất sắt vì thế mà họ luôn cảm thấy mệt mỏi, kiệt sức, hay gắt gỏng trong khi làm việc. Từ năm 1953 chất sắt đã được thêm vào bột bánh mì.
    Theo một nghiên cứu thì 1 lát bánh mì trắng cung cấp 0,6mg trong tổng số 15 mg phụ nữ cần mỗi ngày. Vì vậy 4 lát bánh mì mỗi ngày sẽ giúp bạn tăng lượng sắt và nó thật hữu ích nếu bạn muốn tránh ăn thịt bò và dầu cá.</p>
                    <br>
                    <h5>Giúp cải thiện tâm trạng:</h5>
                    <p>Chúng ta cần chất folate và acid folic để giúp các dây thần kinh khỏe mạnh. Phụ nữ trong độ tuổi sinh đẻ nên có khoảng 400 mcg những chất đó hàng ngày, 4 lát bánh mì sẽ cung cấp 1/4 nhu cầu cho họ.</p>
                    <br>
                    <h5>Giúp giảm béo:</h5>
                    <p>Nếu bạn đang trong chế độ ăn kiêng thì một trong những loại thực phẩm đầu tiên bạn nên nghĩ đến đó là bánh mì. Một lát bánh mì trắng chỉ chứa khoảng 77 calo, ít hơn 6 calo so với một chiếc bánh quy và tương đương với lượng bơ mà bạn dùng kèm với lát bánh mì đó. Vì vậy bánh mì có thể giúp bạn tránh béo phì nếu có chế độ ăn hợp lý.</p>
                    <br>
                    <img src="banh-mi-2.jpg">
                    <br>
                    <h5>Tốt cho tiêu hóa:</h5>
                    <p>Bánh mì cung cấp cho con người chất xơ, nó rất tốt cho tiêu hóa. 2 lát bánh mì nâu được ăn vào bữa trưa sẽ cung cấp 1/3 nhu cầu chất xơ hàng ngày của bạn.
    Chính vì những lý do trên mà chúng ta nên có cái nhìn đúng đắn về bánh mì và có chế độ ăn hợp lý để nhận được hết lợi ích từ bánh mì.
    </p>
    				<br>
                    <img src="bua-sang-ngon-voi-banh-my-nhan-thit-phu-pho-mai.jpg">
                    <br>
                    <p><i>Chúc các bạn ngon miệng với món bánh mỳ nhân thịt phủ phô mai nhé!</i></p>
                </div>
            </div>
        </div>
        <div id="footer">
        	Copyright &copy;2017 by Fang to beens - KTPM5 - K10 - HaUI.
        </div>
	</div>

</body>
</html>
