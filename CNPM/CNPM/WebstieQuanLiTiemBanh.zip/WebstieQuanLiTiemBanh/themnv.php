<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Thêm nhân viên</title>

<style>
p {

font-size:20px;
	
}

input {

height:30px;
	
}

</style>

</head>

<body>
<center>
<br /><br />
<?php
	if ($_GET['th']=='0'){
	echo "<p style="."font-size:20px;color:red;".">Thêm thất bại, mời bạn nhập lại!</p><br/>";	
	}
	if($_GET['th']=='2'){
		
		echo "<p style="."font-size:20px;color:green;".">Thêm nhân viên thành công!</p><br/>";
		
		}
	
	 ?>
	<form action="themthanhcong.php" method="post" enctype="multipart/form-data" >
    <fieldset style="width: 500px">
    	<legend style="font-size:30px">Thêm nhân viên</legend>
        <br />
        <p>Tài khoản: <input type="text" name="taikhoan"></p><br />
        <p>Mật khẩu: <input type="text" name="matkhau"></p><br />
    <!--	<p>Mã NV: <input type="text" name="manv"></p><br /> -->
        <p>Tên NV: <input type="text" name="tennv"></p><br />
        <p>Giới tính: 
        <select style="height:30px" name="gt">
        	<option>Nam</option>
            <option>Nữ</option>
        </select>
        </p><br />
        <p>Năm sinh: <input type="text" name="ngaysinh"></p><br />
        <p>SĐT: <input type="text" name="sdt"></p><br />
        <p style="text-align: center"><input type="submit" value="Thêm" name="thembtn" style="height:30px; width:80px; background:#069; color:#FFF"></p><br />
    </fieldset>
    </form>
    
    </center>
</body>
</html>