		<?php
				
		//	include('connect.php');
					
					include('connect.php');
					
					
					$username = $_POST['taikhoan'];
					
					$password = $_POST['matkhau'];
					
					if (isset($_POST['login'])){
						
						while ($kq = mysql_fetch_array($run)){
						
						if ($username == $kq['username']&&$password == $kq['password']){
							session_start();
							$_SESSION['username'] = $username;
							header('location:test.php?ac=tracuu&th=1');
								break;
						}
						else header('location:index.php');
						
						}
					}
				?>