<?php

include('connect.php');

$manv = $_POST['manv'];

$tennv = $_POST['tennv'];

$gt = $_POST['gt'];

$namsinh = $_POST['namsinh'];

$sdt = $_POST['sdt'];

if (isset($_POST['suabtn'])){
	
	mysql_query("update nhanvien set tennv = '$tennv', gt = '$gt', namsinh = '$namsinh', sdt ='$sdt' where manv = '$manv'");
	mysql_query("update taikhoan set hoten = '$tennv' where id = '$manv'");
	
	header("location:test.php?ac=suanv&th=1");
	
	}
	
	else if(isset($_POST['xoabtn'])){
		
		mysql_query("delete from nhanvien where manv='$manv'");
		mysql_query("delete from taikhoan where id='$manv'");
		
	header("location:test.php?ac=suanv&th=1");
	
	
		}


?>