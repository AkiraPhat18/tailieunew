<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>


<style>


	table {
		
		background: #FFF;
		margin-left: auto;
		margin-right: auto;
		text-align: center;
	}

</style>

</head>

<body>


<h3 style="text-align: center; margin-top: 20px; margin-bottom: 20px;">Thông tin nhân viên</h3>
                    
                    <?php 
					include('connect.php');
					$sql = "select * from nhanvien order by manv asc";
					$run2 = mysql_query($sql);
					?>
                	<table border="1" cellspacing="0">
                    	<tr>
                        	<td>Mã NV</td>
                            <td>Tên NV</td>
                            <td>Giới tính</td>
                            <td>Năm sinh</td>
                            <td>SĐT</td>
                            <td>Update</td>
                            <td>Xóa</td>
                            
                        </tr>
                        
                        <?php
							
							$i =0;
							
							while ($kq=mysql_fetch_array($run2)){
						
						 ?>
                        
                    <form action="updateNV.php" enctype="multipart/form-data" method="post">
                        <tr >
                        	<td style="width:150px; height:60px"><input type="text" name="manv" style=" height:60px; width:40px; padding-left:20px; " value="<?php echo $kq['manv'] ?>" /></td>
                            <td style="width:200px; height:60px"><input type="text" name="tennv" style=" height:60px;width:150px; padding-left:20px" value="<?php echo $kq['tennv'] ?>"/></td>
                            <td style="width:100px; height:60px"><input type="text" name="gt" style=" height:60px;width:80px; padding-left:20px; " value="<?php echo $kq['gt'] ?>"/></td>
                            <td style="width:160px; height:60px"><input type="text" name="namsinh" style=" height:60px;width:80px; padding-left:20px; " value="<?php echo $kq['namsinh'] ?>"/></td>
                            <td style="width:200px; height:60px"><input type="text" name="sdt" style=" height:60px;width:150px; padding-left:20px;  " value="<?php echo "0".$kq['sdt'] ?>"/></td>
                           <td style="width:160px; height:60px"><input type="submit" name="suabtn" style=" height:60px;width:80px; background:#396; color:#FFF" value="Sửa"/></td>
                           <td style="width:160px; height:60px"><input type="submit" name="xoabtn" style=" height:60px;width:80px;background: #F00; color:#FFF " value="Xóa"/></td>
                        </tr>
                        
                    </form>
                        <?php
                        
							$i++;
						
							}
						?>
                        
                    </table>

</body>
</html>